import React from 'react'

export default function Home() {
  return <div style={{fontFamily:'Inter, system-ui, sans-serif', padding:40}}>Vercel-optimized package (navy theme). Replace public/assets/logo.png with your logo. Booking link is wired.</div>
}
